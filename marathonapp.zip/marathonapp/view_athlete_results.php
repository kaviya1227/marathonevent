<?php
// Database connection
$host = "localhost";
$user = "root";
$password = "";
$dbname = "marathon_db";

$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch top 4 athletes based on final rank
$sql = "SELECT athlete_id, speed, distance, endurance, final_rank 
        FROM athlete_performance 
        ORDER BY final_rank ASC 
        LIMIT 4";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Top 4 Athlete Results</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
        }
        table {
            width: 80%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: center;
        }
        th {
            background-color: #007acc;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

    <h2>Top 4 Athlete Performance</h2>

    <table>
        <thead>
            <tr>
                <th>Athlete ID</th>
                <th>Speed (km/h)</th>
                <th>Distance (km)</th>
                <th>Endurance</th>
                <th>Final Rank</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['athlete_id']}</td>
                            <td>{$row['speed']}</td>
                            <td>{$row['distance']}</td>
                            <td>{$row['endurance']}</td>
                            <td>{$row['final_rank']}</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No data found.</td></tr>";
            }
            ?>
        </tbody>
    </table>

</body>
</html>

<?php $conn->close(); ?>
