<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Athlete Event</title>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .container {
            background-image: url('https://img.freepik.com/free-vector/silhouettes-men-racing_1048-1470.jpg');
            background-size: cover;
            background-position: center;
            height: 100vh;
            position: relative;
        }

        .overlay {
            background-color: rgba(0, 0, 0, 0.6); /* Dim the background */
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .content {
            color: white;
            text-align: center;
            padding: 20px;
            max-width: 600px;
            margin: auto;
        }

        .content h1 {
            font-size: 3em;
            margin-bottom: 0.5em;
        }

        .content p {
            font-size: 1.2em;
            margin-bottom: 1.5em;
        }

        .arrow-container {
            margin-top: 20px;
        }

        .arrow-icon {
            width: 60px;
            transition: transform 0.3s ease;
        }

        .arrow-icon:hover {
            transform: scale(1.2);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="overlay">
            <div class="content">
                <h1>WELCOME TO THE APP, MARATHONERS!!!</h1>
                <p>Of all the races, there is no better stage for heroism than a marathon.</p>
                <div class="arrow-container">
                    <a href="ua.php">
                        <img src="arrow.png" alt="Next" class="arrow-icon">
                     
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
