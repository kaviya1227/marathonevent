<?php
include "db.php"; 
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Athlete App</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Athlete App</h1>
        <img src="logo.png" alt="Logo" class="logo">

        <div class="buttons">
            <a href="signup.php" class="btn">Sign Up</a>
            <a href="login.php" class="btn">Login</a>
            
        </div>
    </div>
    
</body>
</html>
