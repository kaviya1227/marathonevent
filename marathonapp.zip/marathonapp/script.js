let dataset = [];

async function loadCSV() {
  const res = await fetch("marathon_positions.csv");
  const data = await res.text();
  const rows = data.trim().split("\n").slice(1);
  dataset = rows.map(row => {
    const cols = row.split(",");
    return {
      eventYear: cols[0], // Year of the event
      eventDate: cols[1], // Event date
      event: cols[2], // Event name
      distance: parseFloat(cols[3]), // Distance
      numFinishers: parseInt(cols[4]), // Number of finishers
      performance: cols[5], // Athlete performance (time, etc.)
      athleteClub: cols[6], // Athlete's club
      athleteCountry: cols[7], // Athlete's country
      athleteYearOfBirth: parseInt(cols[8]), // Athlete year of birth
      athleteGender: cols[9], // Athlete gender
      athleteAgeCategory: cols[10], // Athlete's age category
      avgSpeed: parseFloat(cols[11]), // Average speed
      athleteID: cols[12], // Athlete ID
      athleteAge: parseInt(cols[13]), // Athlete age
      endurance: parseFloat(cols[14]), // Endurance
      position: cols[15], // Athlete's position
      raw: cols // Raw data for debugging
    };
  });
}

// Page 1: index.html (Event Names)
if (location.pathname.includes("index.html")) {
  loadCSV().then(() => {
    const events = [...new Set(dataset.map(d => d.event))]; // Getting unique event names
    const list = document.getElementById("eventList");
    events.forEach(ev => {
      const btn = document.createElement("button");
      btn.textContent = ev;
      btn.onclick = () => {
        localStorage.setItem("selectedEvent", ev);
        window.location.href = "athletes.html";
      };
      list.appendChild(btn);
    });
  });
}

// Page 2: athletes.html (Athlete IDs per Event)
if (location.pathname.includes("athletes.html")) {
  loadCSV().then(() => {
    const event = localStorage.getItem("selectedEvent");
    document.getElementById("eventName").textContent = event;
    const athletes = dataset.filter(d => d.event === event);
    const list = document.getElementById("athleteList");
    athletes.forEach(a => {
      const btn = document.createElement("button");
      btn.textContent = `Athlete ID: ${a.athleteID}`;
      btn.onclick = () => {
        localStorage.setItem("selectedAthleteID", a.athleteID);
        window.location.href = "athlete.html";
      };
      list.appendChild(btn);
    });
  });
}

// Page 3: athlete.html (Athlete Details)
if (location.pathname.includes("athlete.html")) {
  loadCSV().then(() => {
    const athleteID = localStorage.getItem("selectedAthleteID");
    const athlete = dataset.find(a => a.athleteID === athleteID);
    const details = document.getElementById("athleteDetails");

    details.innerHTML = `
      <p><strong>Athlete ID:</strong> ${athlete.athleteID}</p>
      <p><strong>Event:</strong> ${athlete.event}</p>
      <p><strong>Event Year:</strong> ${athlete.eventYear}</p>
      <p><strong>Event Date:</strong> ${athlete.eventDate}</p>
      <p><strong>Distance:</strong> ${athlete.distance} km</p>
      <p><strong>Average Speed:</strong> ${athlete.avgSpeed} km/h</p>
      <p><strong>Endurance:</strong> ${athlete.endurance}</p>
      <p><strong>Position:</strong> ${athlete.position}</p>
      <p><strong>Athlete Country:</strong> ${athlete.athleteCountry}</p>
      <p><strong>Athlete Year of Birth:</strong> ${athlete.athleteYearOfBirth}</p>
      <p><strong>Athlete Gender:</strong> ${athlete.athleteGender}</p>
      <p><strong>Athlete Age Category:</strong> ${athlete.athleteAgeCategory}</p>
      <p><strong>Athlete Age:</strong> ${athlete.athleteAge}</p>
    `;

    // Chart: Average Speed vs Distance
    new Chart(document.getElementById("chart"), {
      type: "line",
      data: {
        labels: ['Distance (km)', 'Average Speed (km/h)'],
        datasets: [{
          label: athlete.athleteID,
          data: [athlete.distance, athlete.avgSpeed],
          fill: false,
          borderColor: "rgba(75, 192, 192, 1)",
          tension: 0.1
        }]
      },
      options: {
        scales: {
          x: { title: { display: true, text: "Distance (km)" }},
          y: { title: { display: true, text: "Average Speed (km/h)" }}
        }
      }
    });
  });
}
