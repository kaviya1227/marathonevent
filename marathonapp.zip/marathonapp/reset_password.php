<?php
session_start();
include "db.php";

if (!isset($_SESSION["reset_email"])) {
    header("Location: forgot_password.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_password = $_POST["new_password"];

    // Validate password criteria
    if (strlen($new_password) < 6 || !preg_match('/[A-Z]/', $new_password) || !preg_match('/[\W]/', $new_password)) {
        $error = "Password must be at least 6 characters, contain an uppercase letter, and a special character.";
    } else {
        $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
        $email = $_SESSION["reset_email"];

        // Update the password in the database
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
        $stmt->bind_param("ss", $hashed_password, $email);

        if ($stmt->execute()) {
            unset($_SESSION["reset_email"]);
            $_SESSION["message"] = "Password reset successful. Please login.";
            header("Location: login.php"); // Redirect to login page after password reset
            exit();
        } else {
            $error = "Failed to reset password.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Reset Password</title><link rel="stylesheet" href="style.css"></head>
<body>
    <form method="post">
        <h2>Create New Password</h2>
        <?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>
        <input type="password" name="new_password" placeholder="Enter new password" required>
        <button type="submit">Reset Password</button>
        <p><a href="login.php">Back to Login</a></p> <!-- Back to login link -->
    </form>
</body>
</html>
