<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin: 0;
            padding: 0;
        }
        .container {
            background: white;
            width: 50%;
            margin: 100px auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #333;
        }
        .buttons {
            margin-top: 20px;
        }
        .btn {
            display: inline-block;
            padding: 15px 30px;
            font-size: 18px;
            color: white;
            background-color: green;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            margin: 10px;
            transition: background 0.3s ease;
        }
        .btn:hover {
            background-color: darkgreen;
        }
    </style>
</head>
<body>
    <div class="container">
        
        <div class="buttons">
            <a href="home.php" class="btn">Event Registration</a>
            <a href="index.html" class="btn">Athlete Result</a>
            <a href="marathon.html" class="btn">Live Score</a>
        </div>
    </div>
</body>
</html>
