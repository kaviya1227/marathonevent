<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="at.css">
</head>
<body>
    <div class="login-container">
        <h2>Select Login</h2>
        <div class="icons">
            <a href="index.php">
                <img src="user_icon.png" alt="User Login" class="login-icon">
                <p>User Login</p>
            </a>
            <a href="admin_login.php">
                <img src="admin_icon.png" alt="Admin Login" class="login-icon">
                <p>Admin Login</p>
            </a>
            <a href="organizer_login.php">
                <img src="organizer_icon.png" alt="Event Organizer Login" class="login-icon">
                <p>Event Organizer Login</p>
            </a>    
        </div>
    </div>
</body>
</html>
