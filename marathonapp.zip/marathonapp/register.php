<?php
include "db.php"; // Use the existing database connection
session_start();

if (!isset($_GET['event_name'])) {
    echo "<script>alert('Invalid event selection!'); window.location='index.php';</script>";
    exit();
}

$event_name = $_GET['event_name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register for Event</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Register for <?php echo $event_name; ?></h2>

        <form action="submit_registration.php" method="POST">
            <input type="hidden" name="event_name" value="<?php echo $event_name; ?>">

            <table>
                <tr>
                    <td><label for="name">Name:</label></td>
                    <td><input type="text" id="name" name="name" required></td>
                </tr>
                <tr>
                    <td><label for="gender">Gender:</label></td>
                    <td>
                        <select id="gender" name="gender" required>
                            <option value="">Select</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td><label for="age_category">Age Category:</label></td>
                    <td>
                        <input type="radio" id="under18" name="age_category" value="Under 18" required> Under 18 <br>
                        <input type="radio" id="under30" name="age_category" value="Under 30"> Under 30
                    </td>
                </tr>
                <tr>
                    <td><label for="age">Age:</label></td>
                    <td><input type="number" id="age" name="age" required></td>
                </tr>
                <tr>
                    <td><label for="address">Address:</label></td>
                    <td><input type="text" id="address" name="address" required></td>
                </tr>
                <tr>
                    <td><label for="mobile">Mobile:</label></td>
                    <td><input type="text" id="mobile" name="mobile" required></td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <button type="submit" class="btn">Register</button>
                    </td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>
