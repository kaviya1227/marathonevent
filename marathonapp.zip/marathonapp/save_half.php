<?php
// Database connection
$host = 'localhost';
$db   = 'marathon_db';
$user = 'root'; // Change to your DB user
$pass = '';     // Change to your DB password
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

// Get JSON input
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON']);
    exit;
}

// Insert data
$stmt = $pdo->prepare("INSERT INTO half_marathon (athlete_id, speed, distance, time, location) VALUES (?, ?, ?, ?, ?)");
$stmt->execute([
    $data['athlete_id'],
    $data['speed'],
    $data['distance'],
    $data['time'],
    $data['location']
]);

echo json_encode(['status' => 'success']);
?>
