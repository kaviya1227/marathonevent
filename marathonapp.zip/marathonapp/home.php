<?php
include "db.php"; // Use existing db.php file
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Athlete Marathon Events</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Athlete Marathon Events</h1>

        <table>
            <thead>
                <tr>
                    <th>Event Name</th>
                    <th>Place</th>
                    <th>Date</th>
                    <th>Age Categories</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>100m Sprint Race</td>
                    <td>Trichy Anna Stadium</td>
                    <td>2025-06-15</td>
                    <td>Under 18, Under 30</td>
                    <td><a href="register.php?event_name=100m Sprint Race" class="btn">Register</a></td>
                </tr>
                <tr>
                    <td>200m Sprint Race</td>
                    <td>Trichy Anna Stadium</td>
                    <td>2025-07-10</td>
                    <td>Under 18, Under 30</td>
                    <td><a href="register.php?event_name=200m Sprint Race" class="btn">Register</a></td>
                </tr>
                <tr>
                    <td>400m Relay Race</td>
                    <td>Trichy Anna Stadium</td>
                    <td>2025-08-05</td>
                    <td>Under 18, Under 30</td>
                    <td><a href="register.php?event_name=400m Relay Race" class="btn">Register</a></td>
                </tr>
                <tr>
                    <td>800m Middle-Distance Race</td>
                    <td>Trichy Anna Stadium</td>
                    <td>2025-09-12</td>
                    <td>Under 18, Under 30</td>
                    <td><a href="register.php?event_name=800m Middle-Distance Race" class="btn">Register</a></td>
                </tr>
                <tr>
                    <td>1500m Endurance Race</td>
                    <td>Trichy Anna Stadium</td>
                    <td>2025-10-20</td>
                    <td>Under 18, Under 30</td>
                    <td><a href="register.php?event_name=1500m Endurance Race" class="btn">Register</a></td>
                </tr>
                <tr>
                    <td>5000m Long-Distance Run</td>
                    <td>Trichy Anna Stadium</td>
                    <td>2025-11-15</td>
                    <td>Under 18, Under 30</td>
                    <td><a href="register.php?event_name=5000m Long-Distance Run" class="btn">Register</a></td>
                </tr>
                <tr>
                    <td>10K Marathon Challenge</td>
                    <td>Trichy Anna Stadium</td>
                    <td>2025-12-05</td>
                    <td>Under 18, Under 30</td>
                    <td><a href="register.php?event_name=10K Marathon Challenge" class="btn">Register</a></td>
                </tr>
                <tr>
                    <td>Half Marathon (21.1K)</td>
                    <td>Trichy Anna Stadium</td>
                    <td>2026-01-15</td>
                    <td>Under 18, Under 30</td>
                    <td><a href="register.php?event_name=Half Marathon (21.1K)" class="btn">Register</a></td>
                </tr>
                <tr>
                    <td>Full Marathon (42.2K)</td>
                    <td>Trichy Anna Stadium</td>
                    <td>2026-02-25</td>
                    <td>Under 18, Under 30</td>
                    <td><a href="register.php?event_name=Full Marathon (42.2K)" class="btn">Register</a></td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>
