<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $admin_id = $_POST['org_id'];
    $password = $_POST['password'];

    // Check hardcoded organizer credentials
    if ($admin_id == "org" && $password == "123") {
        $_SESSION['admin_logged_in'] = true;
        header("Location: org_dashboard.php");
        exit();
    } else {
        $error = "Invalid Organizer ID or Password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Organizer Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Organizer Login</h2>
        <?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>
        <form method="post">
            <label>Organizer ID:</label>
            <input type="text" name="org_id" required>
            
            <label>Password:</label>
            <input type="password" name="password" required>
            
            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>
