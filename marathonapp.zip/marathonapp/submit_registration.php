<?php
include "db.php"; // Use the existing database connection
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $event_name = $_POST['event_name'];
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $age_category = $_POST['age_category'];
    $age = $_POST['age'];
    $address = $_POST['address'];
    $mobile = $_POST['mobile'];

    // Age validation
    if (($age_category == "Under 18" && $age >= 18) || ($age_category == "Under 30" && $age >= 30)) {
        echo "<script>alert('You are not eligible for this category!'); window.location='register.php?event_name=$event_name';</script>";
        exit();
    }

    // Insert into the database
    $sql = "INSERT INTO registrations (event_name, name, gender, age_category, age, address, mobile) 
            VALUES ('$event_name', '$name', '$gender', '$age_category', '$age', '$address', '$mobile')";

    if ($conn->query($sql) === TRUE) {
        header("Location: success.php");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
