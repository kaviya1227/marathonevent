<?php
session_start();
include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];

    // Check if email exists in the database
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Send an email with the reset link (can be enhanced with actual email sending)
        $_SESSION["reset_email"] = $email; // Store email to reset password later
        header("Location: reset_password.php"); // Redirect to reset page
        exit();
    } else {
        $error = "Email not found!";
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Forgot Password</title><link rel="stylesheet" href="style.css"></head>
<body>
    <form method="post">
        <h2>Reset Password</h2>
        <?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>
        <input type="email" name="email" placeholder="Enter your registered email" required>
        <button type="submit">Submit</button>
        <p><a href="login.php">Back to Login</a></p> <!-- Back to login link -->
    </form>
</body>
</html>
