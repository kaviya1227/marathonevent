<?php
include "db.php";
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Password Validation
    if (strlen($password) < 6 || !preg_match('/[A-Z]/', $password) || !preg_match('/[\W]/', $password)) {
        $_SESSION["error"] = "Password must be at least 6 characters, contain an uppercase letter, and a special character.";
    } else {
        // Encrypt Password
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);

        // Store User Data in MySQL
        $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $hashed_password);

        if ($stmt->execute()) {
            $_SESSION["message"] = "Sign-up successful! Please login.";
            header("Location: login.php");
            exit();
        } else {
            $_SESSION["error"] = "Email already registered.";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sign Up</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form action="signup.php" method="post">
        <h2>Sign Up</h2>
        <?php if (isset($_SESSION["error"])) { echo "<p class='error'>".$_SESSION["error"]."</p>"; unset($_SESSION["error"]); } ?>
        <input type="text" name="username" placeholder="Username" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit" class="btn">Sign In</button>
        <p>Already have an account? <a href="login.php">Go to Login</a></p>
    </form>
</body>
</html>
