<!DOCTYPE html>
<html lang="en">
<head>
    <title>Registration Successful</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Registration Successful!</h2>
        <p>Thank you for registering. You will receive event details soon.</p>
        <a href="home.php" class="btn">Back to Home</a>
    </div>
</body>
</html>
