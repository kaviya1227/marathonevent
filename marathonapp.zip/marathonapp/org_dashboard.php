<?php
session_start();
include "db.php"; // Include your database connection

// Check if organizer is logged in
if (!isset($_SESSION['organizer_logged_in'])) {
    header("Location: organizer_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Organizer Dashboard</title>
    <link rel="stylesheet" href="style.css"> <!-- Optional: add your own CSS -->
</head>
<body>
    <div class="container">
        <h1>Organizer Dashboard</h1>
        <a href="ua.php" class="btn">Logout</a>

        <h2>Athlete Performance Summary</h2>
        <table>
            <thead>
                <tr>
                    <th>Athlete ID</th>
                    <th>Speed</th>
                    <th>Distance</th>
                    <th>Endurance</th>
                    <th>Final Rank</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result = $conn->query("SELECT athlete_id, speed, distance, endurance, final_rank FROM athlete_performance");
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['athlete_id']}</td>
                            <td>{$row['speed']}</td>
                            <td>{$row['distance']}</td>
                            <td>{$row['endurance']}</td>
                            <td>{$row['final_rank']}</td>
                          </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
