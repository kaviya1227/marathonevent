import pandas as pd
import numpy as np
import mysql.connector
from sklearn.preprocessing import MinMaxScaler
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

# Database connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="marathon_db"
)
cursor = db.cursor(dictionary=True)

# Query data up to 10km for half marathon
cursor.execute("SELECT * FROM half_marathon WHERE distance <= 10")
half_data = pd.DataFrame(cursor.fetchall())

# Query data up to 22km for full marathon
cursor.execute("SELECT * FROM full_marathon WHERE distance <= 22")
full_data = pd.DataFrame(cursor.fetchall())

# Add race_type to separate half and full
half_data['race_type'] = 'half'
full_data['race_type'] = 'full'

# Combine datasets
data = pd.concat([half_data, full_data], ignore_index=True)

# Ensure necessary columns
features = ['athlete_id', 'speed', 'distance', 'time', 'location', 'race_type']
data = data[features]

# Encode location (categorical) and normalize
data['location'] = data['location'].astype('category').cat.codes
scaler = MinMaxScaler()
scaled_features = scaler.fit_transform(data[['speed', 'distance', 'time', 'location']])
data[['speed', 'distance', 'time', 'location']] = scaled_features

# Prepare sequences by athlete
grouped = data.groupby('athlete_id')
sequence_data = []
race_types = {}

for aid, group in grouped:
    group = group.sort_values(by='distance')
    if len(group) >= 3:
        race_types[aid] = group['race_type'].iloc[0]
        sequence_data.append((aid, group[['speed', 'distance', 'time', 'location']].values))

# LSTM Model
class LSTMModel(nn.Module):
    def __init__(self, input_size=4, hidden_size=32, output_size=2):
        super(LSTMModel, self).__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        _, (hn, _) = self.lstm(x)
        return self.fc(hn[-1])

model = LSTMModel()
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

# Prepare training data
X, y = [], []
max_len = 10

for aid, seq in sequence_data:
    t_seq = torch.tensor(seq, dtype=torch.float32)
    if len(t_seq) >= max_len:
        t_seq = t_seq[:max_len]
    else:
        padding = torch.zeros((max_len - len(t_seq), t_seq.shape[1]))
        t_seq = torch.cat([t_seq, padding], dim=0)
    X.append(t_seq)
    endurance = torch.mean(t_seq[:, 0]).item()
    position = torch.max(t_seq[:, 1]).item()
    y.append([endurance, position])

X_tensor = torch.stack(X)
y_tensor = torch.tensor(y, dtype=torch.float32)
dataset = TensorDataset(X_tensor, y_tensor)
loader = DataLoader(dataset, batch_size=4, shuffle=True)

# Train the model
for epoch in range(20):
    for xb, yb in loader:
        pred = model(xb)
        loss = criterion(pred, yb)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

# Predict endurance and position
results = []
with torch.no_grad():
    for i, (aid, seq) in enumerate(sequence_data):
        input_seq = torch.tensor(seq[np.newaxis, :, :], dtype=torch.float32)
        output = model(input_seq).numpy().flatten()
        endurance, position = output
        last_row = data[data['athlete_id'] == aid].iloc[-1]
        results.append({
            'athlete_id': aid,
            'speed': last_row['speed'],
            'distance': last_row['distance'],
            'time': last_row['time'],
            'location': last_row['location'],
            'endurance': endurance,
            'position': position,
            'race_type': race_types[aid]
        })

# Rank athletes by predicted position (higher is better)
half_results = [r for r in results if r['race_type'] == 'half']
full_results = [r for r in results if r['race_type'] == 'full']

half_sorted = sorted(half_results, key=lambda r: r['position'], reverse=True)
full_sorted = sorted(full_results, key=lambda r: r['position'], reverse=True)

# Assign final ranks
for i, r in enumerate(half_sorted[:4]):
    r['final_rank'] = i + 1

for i, r in enumerate(full_sorted[:4]):
    r['final_rank'] = i + 1

# All other athletes get no rank
for r in half_sorted[4:] + full_sorted[4:]:
    r['final_rank'] = None

# Create table with final_rank
cursor.execute("""
CREATE TABLE IF NOT EXISTS athlete_performance (
    athlete_id VARCHAR(10),
    speed FLOAT,
    distance FLOAT,
    time FLOAT,
    location INT,
    endurance FLOAT,
    position FLOAT,
    race_type VARCHAR(10),
    final_rank INT
)
""")

# Clear old data
cursor.execute("DELETE FROM athlete_performance")

# Insert predictions
for row in half_sorted + full_sorted:
    cursor.execute("""
        INSERT INTO athlete_performance
        (athlete_id, speed, distance, time, location, endurance, position, race_type, final_rank)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
    """, (
        row['athlete_id'],
        float(row['speed']),
        float(row['distance']),
        float(row['time']),
        int(row['location']),
        float(row['endurance']),
        float(row['position']),
        row['race_type'],
        row['final_rank']
    ))

db.commit()
cursor.close()
db.close()
